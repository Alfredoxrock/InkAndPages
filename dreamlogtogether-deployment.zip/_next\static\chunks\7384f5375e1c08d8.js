__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/28776eee28037416.js",
  "static/chunks/turbopack-527dc382e48193ab.js"
])
