__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/28776eee28037416.js",
  "static/chunks/turbopack-1d678b7548027ff5.js"
])
